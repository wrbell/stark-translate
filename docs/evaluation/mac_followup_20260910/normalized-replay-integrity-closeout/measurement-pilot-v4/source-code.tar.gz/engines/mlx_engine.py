"""MLX backend engines for Apple Silicon inference.

Provides:
  - MLXWhisperEngine  -- STT via mlx-whisper (distil-whisper / whisper-large-v3-turbo)
  - MLXGemmaEngine    -- Translation via mlx-lm (TranslateGemma 4B/12B 4-bit)

Note: ``MarianEngine`` (the HF MarianMT partial translator) lives in
``engines.marian_hf_engine`` as ``MarianHFEngine`` since v2026.8. ``PiperTTSEngine``
remains here.
"""

import copy
import logging
import os
import threading
import time
import weakref
from collections import OrderedDict
from collections.abc import Callable

import numpy as np

from engines.base import (
    STTEngine,
    STTResult,
    TranslationEngine,
    TranslationResult,
)
from engines.model_paths import resolve_model_path
from engines.stt_fallback import require_mlx_fallback_language
from engines.translation_prompts import (
    build_chat_messages,
    chat_template_extra_kwargs,
    clean_translation,
    dynamic_max_tokens,
    ensure_stop_tokens,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guard MLX imports -- this module may be imported on non-Apple hardware
# ---------------------------------------------------------------------------
try:
    import mlx.core as mx
    import mlx_lm
    import mlx_whisper

    MLX_AVAILABLE = True
except ImportError:
    mx = None
    mlx_lm = None
    mlx_whisper = None
    MLX_AVAILABLE = False


# Message when --turboquant is requested but no drop-in API exists for mlx_lm.
TURBOQUANT_UNAVAILABLE_MSG = (
    "TurboQuant requested but no drop-in TurboQuantKVCache for mlx_lm.generate. "
    "mlx-optiq 0.4+ imports as 'optiq' and routes KV mixed-precision through "
    "optiq serve/runtime — not a model.kv_cache attribute swap. "
    "Continuing without TurboQuant."
)


def resolve_turboquant_kv_cache_cls():
    """Return TurboQuantKVCache class if a drop-in mlx_lm API exists, else None.

    Historical research assumed ``from mlx_optiq import TurboQuantKVCache``.
    Current mlx-optiq 0.4.x exposes package ``optiq`` and stubs / omits that
    symbol for the mlx_lm path. Try known locations; never raise.
    """
    candidates = (
        "mlx_optiq.TurboQuantKVCache",
        "optiq.TurboQuantKVCache",
        "optiq.vlm._mlxvlm.turboquant.TurboQuantKVCache",
    )
    for dotted in candidates:
        mod_name, _, attr = dotted.rpartition(".")
        try:
            import importlib

            mod = importlib.import_module(mod_name)
            cls = getattr(mod, attr, None)
            if cls is None or not callable(cls):
                continue
            # OptiQ VLM stub: module/class docs mention stub, or __init__ raises
            blob = f"{getattr(cls, '__doc__', '') or ''} {getattr(mod, '__doc__', '') or ''}".lower()
            if "stub" in blob:
                continue
            return cls
        except Exception:
            continue
    return None


def materialize_mlx_model(model) -> None:
    """Eagerly evaluate model parameters for cross-thread use (MLX >= 0.31.2).

    MLX binds lazy arrays to the creating thread's stream. Evaluating parameters
    on the load thread materializes weights so other pool threads can safely run
    independent computations (STT ∥ translation overlap). See ml-explore/mlx#3078
    and #3529.
    """
    if mx is None or model is None:
        return
    try:
        if hasattr(model, "parameters"):
            mx.eval(model.parameters())
        elif hasattr(model, "trainable_parameters"):
            mx.eval(model.trainable_parameters())
        elif hasattr(mx, "synchronize"):
            mx.synchronize()
    except Exception as exc:
        logger.warning("Could not materialize MLX model parameters: %s", exc)


def warm_mlx_model(model, tokenizer, *, model_family: str, label: str = "model", strict: bool = True) -> None:
    """Run the model's *first* forward pass on the load thread (1 token).

    mlx-lm's ``generation_stream`` is a thread-local stream. On mlx 0.32.x the
    first forward pass creates lazily-initialised state bound to the calling
    thread's stream; if that first pass happens on a pool worker, every later
    generation from another thread raises
    ``RuntimeError: There is no Stream(gpu, N) in current thread``. Calling this
    right after ``load()`` (main/load thread) makes the model usable from any
    worker. Verified 2026-09-09 on mlx 0.32.2 / mlx-lm 0.31.3 and mlx-lm main.
    Weight materialisation alone (``materialize_mlx_model``) is not sufficient.
    Startup failures propagate by default; optional later probes may pass
    ``strict=False`` when failure must not invalidate an already loaded model.
    """
    if mx is None or model is None or tokenizer is None:
        return
    try:
        from mlx_lm import generate

        messages = build_chat_messages("Hello.", source_lang="en", target_lang="es", model_family=model_family)
        prompt = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            **chat_template_extra_kwargs(model_family=model_family),
        )
        t0 = time.perf_counter()
        generate(model, tokenizer, prompt=prompt, max_tokens=1, verbose=False)
        if hasattr(mx, "synchronize"):
            mx.synchronize()
        logger.info("%s warm forward on load thread (%.0f ms)", label, (time.perf_counter() - t0) * 1000)
    except Exception as exc:
        logger.warning("%s warm forward failed: %s", label, exc)
        if strict:
            raise RuntimeError(f"{label} warm forward failed: {exc}") from exc


# PyTorch is always available (used as a fallback). Silero VAD on Mac uses
# the shared lock from engines._locks so concurrent calls between MLX engines
# (Metal-bound) and any HF PyTorch path (e.g. MarianHFEngine) are serialized.
import torch  # noqa: F401  -- imported for downstream guards

# ---------------------------------------------------------------------------
# MLX Whisper STT
# ---------------------------------------------------------------------------


class MLXWhisperEngine(STTEngine):
    """Speech-to-text engine wrapping mlx-whisper.

    Constructor args:
        model_id:                HuggingFace repo for the primary model
                                 (default: mlx-community/whisper-large-v3-turbo).
        fallback_model_id:       Used for quality-based retry when the primary
                                 model returns low-confidence output
                                 (default: wbell7/distil-whisper-large-v3.5-mlx).
        cache_limit_mb:          Metal memory cache limit in megabytes (default: 256).
        fallback_threshold:      avg_logprob below which to retry with fallback
                                 model (default: -1.2).
        hallucination_threshold: compression_ratio above which output is flagged
                                 as hallucination and retried (default: 2.4).
        fallback_on_low_conf:    Enable/disable the quality-based fallback retry
                                 (default: True).
        session_language:       Language used to guard startup fallback (default:
                                 English). Automatic fallback is EN-only, including
                                 custom fallback IDs. Spanish primary output is kept
                                 on low confidence without an incompatible retry.
    """

    def __init__(
        self,
        model_id: str = "mlx-community/whisper-large-v3-turbo",
        fallback_model_id: str = "wbell7/distil-whisper-large-v3.5-mlx",
        cache_limit_mb: int = 256,
        fallback_threshold: float = -1.2,
        hallucination_threshold: float = 2.4,
        fallback_on_low_conf: bool = True,
        session_language: str = "en",
    ):
        if not MLX_AVAILABLE:
            raise RuntimeError(
                "MLX is not available. MLXWhisperEngine requires Apple Silicon "
                "with mlx, mlx-whisper, and mlx-lm installed."
            )
        self._model_id = model_id
        self._fallback_model_id = fallback_model_id
        self._cache_limit_mb = cache_limit_mb
        self._fallback_threshold = fallback_threshold
        self._hallucination_threshold = hallucination_threshold
        self._fallback_on_low_conf = fallback_on_low_conf
        self._session_language = session_language
        self._startup_used_fallback = False
        self._fallback_loaded = False
        self._loaded = False

    # -- public interface ----------------------------------------------------

    def load(self) -> None:
        """Download (if needed) and warm up the Whisper model.

        Sets the MLX Metal cache limit, then runs a 1-second silence through
        the model to trigger compilation and weight loading.  Falls back to
        ``fallback_model_id`` if the primary model errors out.
        """
        mx.set_cache_limit(self._cache_limit_mb * 1024 * 1024)

        logger.info("Loading %s (MLX)...", self._model_id)
        t0 = time.time()
        silence = np.zeros(16000, dtype=np.float32)
        try:
            mlx_whisper.transcribe(
                silence,
                path_or_hf_repo=resolve_model_path(self._model_id),
                condition_on_previous_text=False,
            )
            logger.info("Whisper ready (%s) (%.1fs)", self._model_id, time.time() - t0)
        except Exception as exc:
            require_mlx_fallback_language(self._session_language, self._fallback_model_id)
            logger.warning(
                "Primary model %s failed (%s), falling back to %s",
                self._model_id,
                exc,
                self._fallback_model_id,
            )
            self._model_id = self._fallback_model_id
            t0 = time.time()
            mlx_whisper.transcribe(
                silence,
                path_or_hf_repo=resolve_model_path(self._model_id),
                condition_on_previous_text=False,
            )
            logger.info("Whisper ready (%s) (%.1fs)", self._model_id, time.time() - t0)
            self._startup_used_fallback = True

        # Warmup already eval'd graphs on this thread; synchronize so the
        # mlx-whisper cache is safe for pool workers (MLX >= 0.31.2 TLS streams).
        if hasattr(mx, "synchronize"):
            mx.synchronize()

        self._loaded = True

    def transcribe(
        self,
        audio: np.ndarray,
        *,
        language: str = "en",
        initial_prompt: str | None = None,
        word_timestamps: bool = False,
        beam_size: int | None = None,
    ) -> STTResult:
        """Transcribe *audio* (16 kHz float32 mono) to text.

        Returns an ``STTResult`` with segment-level metadata and per-word
        confidence extraction.  When ``fallback_on_low_conf`` is enabled,
        automatically retries with the fallback model if the primary result
        has ``avg_logprob < fallback_threshold`` or
        ``compression_ratio > hallucination_threshold``.

        MLX >= 0.31.2 supports independent multi-thread eval via thread-local
        streams. Callers may overlap STT with translation on separate pool
        threads after ``load()`` materializes weights. Fallback still runs on
        the same worker thread as the primary call (no cross-thread handoff).
        """
        if not self._loaded:
            raise RuntimeError("Engine not loaded -- call load() first")

        # A default-English caller may later request Spanish on the same engine.
        # Never run that request on a fallback selected during startup.
        if self._startup_used_fallback:
            require_mlx_fallback_language(language, self._fallback_model_id)

        primary_result = self._raw_transcribe(
            audio,
            model_repo=self._model_id,
            language=language,
            initial_prompt=initial_prompt,
            word_timestamps=word_timestamps,
            beam_size=beam_size,
        )

        # -- quality-based fallback retry ------------------------------------
        if not self._fallback_on_low_conf or language != "en":
            return primary_result

        needs_fallback = self._should_fallback(primary_result)
        if not needs_fallback:
            return primary_result

        # Lazy-load fallback model on first use (runs warmup transcription)
        if not self._fallback_loaded:
            self._load_fallback_model()

        logger.info(
            "Fallback triggered (avg_logprob=%.3f, compression_ratio=%.2f) -- retrying with %s",
            primary_result.avg_logprob or 0.0,
            primary_result.compression_ratio or 0.0,
            self._fallback_model_id,
        )

        retry_result = self._raw_transcribe(
            audio,
            model_repo=self._fallback_model_id,
            language=language,
            initial_prompt=initial_prompt,
            word_timestamps=word_timestamps,
            beam_size=beam_size,
        )

        # Pick the better result (higher confidence = less negative logprob)
        chosen, chosen_label = self._pick_best(primary_result, retry_result)
        chosen.used_fallback = True

        logger.info(
            "Fallback result: chose %s (primary conf=%.2f avg_lp=%.3f, retry conf=%.2f avg_lp=%.3f)",
            chosen_label,
            primary_result.confidence or 0.0,
            primary_result.avg_logprob or 0.0,
            retry_result.confidence or 0.0,
            retry_result.avg_logprob or 0.0,
        )

        # Log for active learning pipeline
        self._log_fallback(primary_result, retry_result, audio, chosen_label)

        return chosen

    # -- internal helpers ----------------------------------------------------

    def _raw_transcribe(
        self,
        audio: np.ndarray,
        *,
        model_repo: str,
        language: str = "en",
        initial_prompt: str | None = None,
        word_timestamps: bool = False,
        beam_size: int | None = None,
    ) -> STTResult:
        """Run mlx-whisper transcription against a specific model repo.

        This is the core transcription logic extracted so it can be called
        for both the primary and fallback models.

        Note: ``beam_size`` is accepted for interface compatibility with
        FasterWhisperEngine but ignored here — mlx-whisper only supports
        greedy decoding (beam search is not implemented).
        """
        t0 = time.perf_counter()
        # mlx-whisper is always greedy; beam_size param is ignored
        result = mlx_whisper.transcribe(
            audio,
            path_or_hf_repo=resolve_model_path(model_repo),
            language=language,
            condition_on_previous_text=False,
            initial_prompt=initial_prompt,
            word_timestamps=word_timestamps,
        )
        latency_ms = (time.perf_counter() - t0) * 1000
        english = result["text"].strip()

        # -- extract segment metadata (mirrors dry_run_ab._run_stt_mlx) ------
        confidence = None
        segment_meta = []
        low_conf_words = []
        overall_avg_logprob = None
        overall_compression_ratio = None
        segments = result.get("segments", [])
        if segments:
            avg_logprobs = []
            compression_ratios = []
            for seg in segments:
                meta = {
                    "avg_logprob": seg.get("avg_logprob"),
                    "no_speech_prob": seg.get("no_speech_prob"),
                    "compression_ratio": seg.get("compression_ratio"),
                }
                segment_meta.append(meta)
                if meta["avg_logprob"] is not None:
                    avg_logprobs.append(meta["avg_logprob"])
                if meta["compression_ratio"] is not None:
                    compression_ratios.append(meta["compression_ratio"])
                # Per-word confidence
                for w in seg.get("words", []):
                    if w.get("probability", 1.0) < 0.5:
                        low_conf_words.append(
                            {
                                "word": w.get("word", ""),
                                "probability": round(w["probability"], 3),
                                "start": w.get("start"),
                                "end": w.get("end"),
                            }
                        )
            if avg_logprobs:
                overall_avg_logprob = sum(avg_logprobs) / len(avg_logprobs)
                confidence = round(min(1.0, max(0.0, 1.0 + overall_avg_logprob)), 2)
            if compression_ratios:
                overall_compression_ratio = max(compression_ratios)

        return STTResult(
            text=english,
            latency_ms=latency_ms,
            confidence=confidence,
            avg_logprob=overall_avg_logprob,
            compression_ratio=overall_compression_ratio,
            segments=segment_meta,
            low_confidence_words=low_conf_words,
        )

    def _should_fallback(self, result: STTResult) -> bool:
        """Check whether a transcription result warrants a fallback retry."""
        if result.avg_logprob is not None and result.avg_logprob < self._fallback_threshold:
            return True
        if result.compression_ratio is not None and result.compression_ratio > self._hallucination_threshold:
            return True
        return False

    def _load_fallback_model(self) -> None:
        """Lazily load the fallback Whisper model (warmup with 1s silence).

        Only called on first fallback trigger, not at startup.
        Runs on the same worker thread as the primary call (no cross-thread
        handoff of lazy arrays).
        """
        logger.info("Lazy-loading fallback model %s (MLX)...", self._fallback_model_id)
        t0 = time.time()
        silence = np.zeros(16000, dtype=np.float32)
        mlx_whisper.transcribe(
            silence,
            path_or_hf_repo=resolve_model_path(self._fallback_model_id),
            condition_on_previous_text=False,
        )
        if hasattr(mx, "synchronize"):
            mx.synchronize()
        logger.info(
            "Fallback model ready (%s) (%.1fs)",
            self._fallback_model_id,
            time.time() - t0,
        )
        self._fallback_loaded = True

    @staticmethod
    def _pick_best(primary: STTResult, retry: STTResult) -> tuple:
        """Return (best_result, label) choosing the higher-confidence result.

        Compares avg_logprob (less negative = better).  Falls back to
        confidence score if avg_logprob is unavailable.

        Returns:
            Tuple of (STTResult, str) where str is "original" or "retry".
        """
        primary_score = primary.avg_logprob if primary.avg_logprob is not None else -999.0
        retry_score = retry.avg_logprob if retry.avg_logprob is not None else -999.0

        if retry_score > primary_score:
            return retry, "retry"
        return primary, "original"

    def _log_fallback(
        self,
        original: STTResult,
        retry: STTResult,
        audio: np.ndarray,
        chosen_label: str,
    ) -> None:
        """Log the fallback event for active learning.

        Computes a simple hash of the audio chunk for deduplication.
        """
        import hashlib

        from engines.active_learning import log_fallback_event

        # Quick hash of audio bytes for dedup/linking
        audio_bytes = audio.tobytes()
        audio_hash = hashlib.sha256(audio_bytes).hexdigest()[:16]

        log_fallback_event(
            original=original,
            retry=retry,
            audio_hash=audio_hash,
            chosen=chosen_label,
            primary_model=self._model_id,
            fallback_model=self._fallback_model_id,
        )

    def unload(self) -> None:
        """Release references.  MLX models are managed by the framework cache."""
        self._loaded = False
        self._fallback_loaded = False
        logger.info("MLXWhisperEngine unloaded (%s)", self._model_id)

    @property
    def model_id(self) -> str:
        return self._model_id

    @property
    def backend(self) -> str:
        return "mlx"


# ---------------------------------------------------------------------------
# MLX TranslateGemma
# ---------------------------------------------------------------------------

_prefix_stores = OrderedDict()
_prefix_stores_lock = threading.Lock()


def _prefix_store(model):
    from engines.prefix_cache import FixedPrefixStore

    key = id(model)
    try:
        reference = weakref.ref(model)
    except TypeError:
        # Never retain an ID-only cache for a holder whose lifetime cannot be
        # observed: Python may reuse that ID for another model.
        return FixedPrefixStore()
    with _prefix_stores_lock:
        if key not in _prefix_stores or _prefix_stores[key][0]() is not model:
            _prefix_stores[key] = (reference, FixedPrefixStore())
            weakref.finalize(model, _forget_prefix_store, key)
            while len(_prefix_stores) > 4:
                _prefix_stores.popitem(last=False)
        _prefix_stores.move_to_end(key)
        return _prefix_stores[key][1]


def _forget_prefix_store(key):
    with _prefix_stores_lock:
        _prefix_stores.pop(key, None)


def _prompt_tokens(tokenizer, prompt):
    if not isinstance(prompt, str):
        return list(prompt)
    bos = getattr(tokenizer, "bos_token", None)
    return list(tokenizer.encode(prompt, add_special_tokens=bos is None or not prompt.startswith(bos)))


def _prepare_gemma_prefix(model, tokenizer, gen_kwargs, options):
    from mlx_lm.generate import generate_step
    from mlx_lm.models.cache import make_prompt_cache

    from engines.prefix_cache import shared_token_prefix

    full_prompt = _prompt_tokens(tokenizer, gen_kwargs["prompt"])
    probes = []
    for text in ("Alpha", "¿Por qué?", "Ω", ""):
        messages = build_chat_messages(text, model_family="gemma4", **options)
        probes.append(
            _prompt_tokens(
                tokenizer, tokenizer.apply_chat_template(messages, add_generation_prompt=True, enable_thinking=False)
            )
        )
    prefix = shared_token_prefix(probes)

    def prefill(tokens, cache):
        for _ in generate_step(mx.array(tokens), model, max_tokens=0, prompt_cache=cache):
            pass
        mx.eval([entry.state for entry in cache])

    prepared = _prefix_store(model).prepare(prefix, full_prompt, lambda: make_prompt_cache(model), prefill)
    if prepared.cache is not None:
        gen_kwargs["prompt"] = prepared.prompt
        gen_kwargs["prompt_cache"] = prepared.cache
    return prepared, len(full_prompt)


def generate_translation(
    model,
    tokenizer,
    *,
    model_family: str,
    gen_kwargs: dict,
    token_callback: Callable[[str, int], None] | None = None,
    batch_size: int = 3,
) -> TranslationResult:
    """Serialize target/draft access; separate STT and translation models overlap."""
    from engines.mlx_generation_lock import generation_guard

    gen_kwargs = dict(gen_kwargs)
    prefix_options = gen_kwargs.pop("_stark_prefix_options", None)
    measure_lock = prefix_options is not None or os.environ.get("STARK_EXPERIMENT_TRACE", "").lower() in {"true", "1"}
    requested = time.perf_counter() if measure_lock else None
    with generation_guard(model, gen_kwargs.get("draft_model")):
        lock_ms = (time.perf_counter() - requested) * 1000 if requested is not None else None
        prepared, original_tokens = None, None
        prepare_ms = 0.0
        if prefix_options is not None:
            prepare_started = time.perf_counter()
            prepared, original_tokens = _prepare_gemma_prefix(model, tokenizer, gen_kwargs, prefix_options)
            prepare_ms = (time.perf_counter() - prepare_started) * 1000
        result = _generate_translation(
            model,
            tokenizer,
            model_family=model_family,
            gen_kwargs=gen_kwargs,
            token_callback=token_callback,
            batch_size=batch_size,
        )
        result.generation_lock_wait_ms = lock_ms
        if prepared is not None:
            result.cached_prompt_tokens = prepared.cached_tokens
            result.prompt_cache_hit = prepared.hit
            result.prompt_cache_prepare_ms = prepare_ms
            result.prompt_tokens = original_tokens
            result.latency_ms += prepare_ms
            if result.ttft_ms is not None:
                result.ttft_ms += prepare_ms
        return result


def _generate_translation(
    model,
    tokenizer,
    *,
    model_family: str,
    gen_kwargs: dict,
    token_callback: Callable[[str, int], None] | None = None,
    batch_size: int = 3,
) -> TranslationResult:
    """Consume mlx-lm responses once for text, callbacks, and generation telemetry.

    Draft acceptance is the share of generated tokens supplied by the draft;
    mlx-lm does not expose the number of rejected draft proposals here.
    """
    from mlx_lm import stream_generate

    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    t0 = time.perf_counter()
    accumulated = ""
    first_ms = None
    last = None
    draft_tokens = 0
    last_sent_tokens = 0
    for response in stream_generate(model, tokenizer, **gen_kwargs):
        if first_ms is None:
            first_ms = (time.perf_counter() - t0) * 1000
        last = response
        accumulated += response.text
        draft_tokens += int(bool(getattr(response, "from_draft", False)))
        tokens = response.generation_tokens
        if token_callback and tokens - last_sent_tokens >= batch_size:
            token_callback(clean_translation(accumulated, model_family=model_family), tokens)
            last_sent_tokens = tokens

    latency_ms = (time.perf_counter() - t0) * 1000
    prompt_tokens = getattr(last, "prompt_tokens", None)
    prompt_tps = getattr(last, "prompt_tps", None)
    generated_tokens = getattr(last, "generation_tokens", None)
    return TranslationResult(
        text=clean_translation(accumulated, model_family=model_family),
        latency_ms=latency_ms,
        tokens_per_second=getattr(last, "generation_tps", None) or 0.0,
        prompt_tokens=prompt_tokens,
        generated_tokens=generated_tokens,
        prefill_ms=prompt_tokens / prompt_tps * 1000 if prompt_tokens is not None and prompt_tps else None,
        ttft_ms=first_ms,
        decode_ms=max(0.0, latency_ms - first_ms) if first_ms is not None else None,
        finish_reason=getattr(last, "finish_reason", None),
        draft_tokens=draft_tokens if last is not None else None,
        draft_accept_rate=draft_tokens / generated_tokens if generated_tokens else None,
    )


def translate_loaded_model(
    model,
    tokenizer,
    text,
    *,
    model_family="gemma4",
    source_lang="en",
    target_lang="es",
    draft_model=None,
    num_draft_tokens=1,
    prompt_cache_template=None,
    suffix_tokens=None,
    token_callback=None,
    batch_size=3,
    terminology_prompt="none",
):
    """Canonical preparation/generation path for live, engine and worker calls."""
    if model is None or tokenizer is None:
        return TranslationResult(text="(model not loaded)", latency_ms=0.0)
    use_cache = (
        prompt_cache_template is not None
        and suffix_tokens is not None
        and draft_model is None
        and model_family == "translategemma"
    )
    gen_kwargs = {"max_tokens": dynamic_max_tokens(text)}
    if use_cache:
        copy_started = time.perf_counter()
        gen_kwargs["prompt_cache"] = copy.deepcopy(prompt_cache_template)
        copy_ms = (time.perf_counter() - copy_started) * 1000
        if copy_ms > 20:
            logger.warning("prompt_cache deep-copy took %.1fms", copy_ms)
        gen_kwargs["prompt"] = tokenizer.encode(text, add_special_tokens=False) + suffix_tokens
    else:
        messages = build_chat_messages(
            text,
            source_lang=source_lang,
            target_lang=target_lang,
            model_family=model_family,
            terminology_prompt=terminology_prompt,
        )
        gen_kwargs["prompt"] = tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, **chat_template_extra_kwargs(model_family=model_family)
        )
    if draft_model is not None and num_draft_tokens > 0:
        gen_kwargs.update(draft_model=draft_model, num_draft_tokens=num_draft_tokens)
    if model_family == "gemma4" and os.environ.get("STARK_EXPERIMENT_GEMMA_PREFIX_CACHE", "").lower() in {"true", "1"}:
        if draft_model is not None:
            raise ValueError("Gemma fixed-prefix caching cannot be combined with speculative token decoding")
        gen_kwargs["_stark_prefix_options"] = {
            "source_lang": source_lang,
            "target_lang": target_lang,
            "terminology_prompt": terminology_prompt,
        }
    return generate_translation(
        model,
        tokenizer,
        model_family=model_family,
        gen_kwargs=gen_kwargs,
        token_callback=token_callback,
        batch_size=batch_size,
    )


class MLXGemmaEngine(TranslationEngine):
    """Translation engine wrapping Gemma 4 OptiQ / TranslateGemma via mlx-lm.

    Constructor args:
        model_id:        MLX-community model repo (default: Gemma 4 E4B OptiQ).
        cache_limit_mb:  Metal memory cache limit in megabytes (default: 256).
        use_prompt_cache: Pre-compute KV cache for the fixed chat template
                          prefix (TranslateGemma only; skipped for gemma4).
        adapter_path:    Optional LoRA adapter directory passed to
                         ``mlx_lm.load(..., adapter_path=)``.
        use_turboquant:  Request TurboQuant KV cache (soft-disabled on mlx-optiq 0.4).
        turboquant_key_bits / turboquant_val_bits: Quantization bits for TQ.
        model_family:    ``gemma4`` (Mac default) or ``translategemma``.
        draft_model_id:  Optional mlx-lm draft / Gemma-4 ``-assistant`` model for
                         speculative decoding (MTS). Loaded alongside the target.
        num_draft_tokens: Tokens drafted per verify step (gamma). Default 1 — optimal
                          on Metal for Gemma-4 assistant drafters per mlx-optiq.
    """

    def __init__(
        self,
        model_id: str = "mlx-community/gemma-4-e4b-it-OptiQ-4bit",
        cache_limit_mb: int = 256,
        use_prompt_cache: bool = True,
        use_turboquant: bool = False,
        turboquant_key_bits: int = 3,
        turboquant_val_bits: int = 4,
        model_family: str = "gemma4",
        adapter_path: str | None = None,
        draft_model_id: str | None = None,
        num_draft_tokens: int = 1,
        terminology_prompt: str = "none",
    ):
        if not MLX_AVAILABLE:
            raise RuntimeError(
                "MLX is not available. MLXGemmaEngine requires Apple Silicon with mlx and mlx-lm installed."
            )
        self._model_id = model_id
        self._cache_limit_mb = cache_limit_mb
        self._use_prompt_cache = use_prompt_cache
        self._use_turboquant = use_turboquant
        self._turboquant_key_bits = turboquant_key_bits
        self._turboquant_val_bits = turboquant_val_bits
        self._model_family = model_family
        self._adapter_path = adapter_path
        self._draft_model_id = draft_model_id
        self._num_draft_tokens = num_draft_tokens
        self._terminology_prompt = terminology_prompt

        self._model = None
        self._tokenizer = None
        self._draft_model = None
        self._prompt_cache_template = None
        self._suffix_tokens = None
        self._loaded = False

    # -- public interface ----------------------------------------------------

    def load(self) -> None:
        """Load the model weights, apply the EOS fix, and build the prompt cache."""
        from mlx_lm import load as mlx_load

        cache_mb = self._cache_limit_mb
        experimental_limit = os.environ.get("STARK_EXPERIMENT_MLX_CACHE_MB")
        if experimental_limit is not None:
            cache_mb = int(experimental_limit)
            if not 0 <= cache_mb <= 1024:
                raise ValueError("Experimental MLX allocation cache must be between 0 and 1024 MiB")
        mx.set_cache_limit(cache_mb * 1024 * 1024)
        logger.info("MLX reusable allocation cache limit: %d MiB", cache_mb)

        logger.info("Loading %s (MLX 4-bit)...", self._model_id)
        t0 = time.time()
        load_kwargs: dict = {}
        if self._adapter_path:
            load_kwargs["adapter_path"] = self._adapter_path
            logger.info("Loading LoRA adapter from %s", self._adapter_path)
        self._model, self._tokenizer = mlx_load(resolve_model_path(self._model_id), **load_kwargs)

        ensure_stop_tokens(self._tokenizer, model_family=self._model_family)

        elapsed = time.time() - t0
        logger.info("%s loaded (%.1fs)", self._model_id, elapsed)

        # -- Optional draft / Gemma-4 assistant model for speculative decode --
        # mlx-lm accepts draft_model= on generate(). For Gemma-4 OptiQ, pass the
        # matching ``-assistant-bf16`` id (E4B only). TG A/B historically used
        # 4B as draft for 12B via dry_run_ab; that path still works when
        # draft_model_id points at a compatible mlx-lm checkpoint.
        if self._draft_model_id:
            logger.info(
                "Loading draft/MTS model %s (num_draft_tokens=%d)...",
                self._draft_model_id,
                self._num_draft_tokens,
            )
            t1 = time.time()
            self._draft_model, _draft_tok = mlx_load(resolve_model_path(self._draft_model_id))
            logger.info("Draft model loaded (%.1fs)", time.time() - t1)
            # Speculative decode is incompatible with prompt KV cache
            if self._use_prompt_cache:
                logger.info("Disabling prompt cache (incompatible with draft_model)")
                self._use_prompt_cache = False

        # -- TurboQuant KV cache compression (optional drop-in) ---------------
        # Historical API: replace model.kv_cache with TurboQuantKVCache.
        # mlx-optiq 0.4+ does not expose that drop-in for mlx_lm.generate.
        if self._use_turboquant:
            try:
                turbo_cls = resolve_turboquant_kv_cache_cls()
                if turbo_cls is None:
                    logger.warning(TURBOQUANT_UNAVAILABLE_MSG)
                else:
                    self._model.kv_cache = turbo_cls(
                        self._model,
                        key_bits=self._turboquant_key_bits,
                        val_bits=self._turboquant_val_bits,
                        rotate=True,
                    )
                    logger.info(
                        "TurboQuant KV cache enabled (key=%d-bit, val=%d-bit, rotate=True)",
                        self._turboquant_key_bits,
                        self._turboquant_val_bits,
                    )
            except Exception as exc:
                logger.warning("TurboQuant initialization failed: %s", exc)

        # -- prompt cache (mirrors dry_run_ab._build_prompt_cache) ------------
        if self._use_prompt_cache and self._model_family == "translategemma":
            self._prompt_cache_template, self._suffix_tokens = self._build_prompt_cache()

        # Materialize weights on the load thread so pool workers can run
        # independent inference (MLX >= 0.31.2 thread-local streams).
        materialize_mlx_model(self._model)
        if self._draft_model is not None:
            materialize_mlx_model(self._draft_model)
        # First forward pass must happen on the load thread (thread-local stream).
        warm_mlx_model(self._model, self._tokenizer, model_family=self._model_family, label=self._model_id)

        self._loaded = True

    def translate(
        self,
        text: str,
        *,
        source_lang: str = "en",
        target_lang: str = "es",
    ) -> TranslationResult:
        """Translate using the same generation and telemetry path as streaming."""
        return self._translate(text, source_lang=source_lang, target_lang=target_lang)

    def translate_streaming(
        self,
        text: str,
        *,
        source_lang: str = "en",
        target_lang: str = "es",
        token_callback: Callable[[str, int], None] | None = None,
        batch_size: int = 3,
    ) -> TranslationResult:
        """Call token_callback(cleaned_partial, tokens_so_far) every batch_size tokens."""
        return self._translate(
            text,
            source_lang=source_lang,
            target_lang=target_lang,
            token_callback=token_callback,
            batch_size=batch_size,
        )

    def _translate(
        self,
        text: str,
        *,
        source_lang: str,
        target_lang: str,
        token_callback: Callable[[str, int], None] | None = None,
        batch_size: int = 3,
    ) -> TranslationResult:
        if not self._loaded:
            raise RuntimeError("Engine not loaded -- call load() first")

        if self._model is None or self._tokenizer is None:
            return TranslationResult(text="(model not loaded)", latency_ms=0.0)

        use_cache = source_lang == "en" and target_lang == "es"
        return translate_loaded_model(
            self._model,
            self._tokenizer,
            text,
            model_family=self._model_family,
            source_lang=source_lang,
            target_lang=target_lang,
            draft_model=self._draft_model,
            num_draft_tokens=self._num_draft_tokens,
            prompt_cache_template=self._prompt_cache_template if use_cache else None,
            suffix_tokens=self._suffix_tokens if use_cache else None,
            token_callback=token_callback,
            batch_size=batch_size,
            terminology_prompt=self._terminology_prompt,
        )

    def unload(self) -> None:
        """Release model and caches from memory."""
        self._model = None
        self._tokenizer = None
        self._draft_model = None
        self._prompt_cache_template = None
        self._suffix_tokens = None
        self._loaded = False
        logger.info("MLXGemmaEngine unloaded (%s)", self._model_id)

    @property
    def model_id(self) -> str:
        return self._model_id

    @property
    def backend(self) -> str:
        return "mlx"

    # -- internals -----------------------------------------------------------

    def _build_prompt_cache(self):
        """Pre-compute KV cache for the fixed TranslateGemma chat template prefix.

        The chat template has a fixed prefix (system tokens + language codes)
        that is identical for every translation.  By pre-filling the KV cache
        once at load time, we skip re-computing those ~30-40 tokens each call
        (saves ~50-80 ms).

        Returns (prompt_cache, suffix_tokens) or (None, None) on failure.
        """
        from mlx_lm.generate import generate_step
        from mlx_lm.models.cache import make_prompt_cache

        marker = "SPLIT_HERE"
        messages = [
            {
                "role": "user",
                "content": [{"type": "text", "source_lang_code": "en", "target_lang_code": "es", "text": marker}],
            }
        ]
        full_prompt = self._tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
        )
        if isinstance(full_prompt, str):
            full_tokens = self._tokenizer.encode(full_prompt, add_special_tokens=False)
        else:
            full_tokens = list(full_prompt)

        marker_tokens = self._tokenizer.encode(marker, add_special_tokens=False)
        marker_len = len(marker_tokens)

        # Locate the marker in the token sequence
        prefix_end = None
        for i in range(len(full_tokens) - marker_len + 1):
            if full_tokens[i : i + marker_len] == marker_tokens:
                prefix_end = i
                break

        if prefix_end is None:
            logger.warning("Could not locate marker in prompt for %s, skipping cache", self._model_id)
            return None, None

        prefix_tokens = full_tokens[:prefix_end]
        suffix_tokens = full_tokens[prefix_end + marker_len :]

        if len(prefix_tokens) < 3:
            logger.warning("Prefix too short (%d tokens) for %s, skipping cache", len(prefix_tokens), self._model_id)
            return None, suffix_tokens

        # Create and pre-fill the KV cache
        prompt_cache = make_prompt_cache(self._model)
        prompt_array = mx.array(prefix_tokens)

        for _ in generate_step(
            prompt_array,
            self._model,
            max_tokens=0,
            prompt_cache=prompt_cache,
        ):
            pass  # max_tokens=0 means no tokens generated, just prefill

        mx.eval([c.state for c in prompt_cache])
        logger.info(
            "Prompt cache built: %d prefix tokens cached, %d suffix tokens",
            len(prefix_tokens),
            len(suffix_tokens),
        )
        return prompt_cache, suffix_tokens


# ---------------------------------------------------------------------------
# Piper TTS (ONNX Runtime -- works on any backend, thread-safe)
# ---------------------------------------------------------------------------


from engines.tts_engine import PiperTTSEngine  # noqa: F401 -- historical import compatibility
