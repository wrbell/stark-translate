"""Shared fixtures for the test suite.

All tests run on Ubuntu CI without GPU, torch, mlx, or model downloads.
Heavy dependencies are mocked at the module level.
"""

import sys
from unittest.mock import MagicMock

import pytest

# ---------------------------------------------------------------------------
# Mock heavy optional dependencies before any project imports
# ---------------------------------------------------------------------------

_MOCK_MODULES = [
    "mlx",
    "mlx.core",
    "mlx_lm",
    "mlx_lm.utils",
    "mlx_whisper",
    "parakeet_mlx",
    "parakeet_mlx.audio",
    "parakeet_mlx.alignment",
    "optiq",
    "optiq.runtime",
    "optiq.runtime.spec",
    "torch",
    "torch.cuda",
    "transformers",
    "faster_whisper",
    "ctranslate2",
    "sounddevice",
    "websockets",
    "pyannote",
    "pyannote.audio",
    "pyannote.core",
    "speechbrain",
    "speechbrain.pretrained",
    "speechbrain.inference",
    "speechbrain.inference.speaker",
    "silero_vad",
    "noisereduce",
    "demucs",
    "scipy",
    "scipy.io",
    "scipy.io.wavfile",
    "jiwer",
    "youtube_transcript_api",
    "bitsandbytes",
    "yt_dlp",
    "language_tool_python",
    "sentence_transformers",
    "streamlink",
    "soundfile",
    "deepgram",
    "nemo",
    "nemo.collections",
    "nemo.collections.asr",
]

# ---------------------------------------------------------------------------
# Pre-install mocks at module level so that top-level imports in test fixtures
# (e.g. `import dry_run_ab`) don't fail during collection.  The per-test
# monkeypatch fixture below re-applies them for proper cleanup.
# ---------------------------------------------------------------------------
for _mod in _MOCK_MODULES:
    if _mod not in sys.modules:
        sys.modules[_mod] = MagicMock()


class MockPortAudioError(Exception):
    """An exception class, since MagicMock cannot be used in an except clause."""


sys.modules["sounddevice"].PortAudioError = MockPortAudioError


@pytest.fixture(autouse=True)
def _mock_heavy_deps(monkeypatch):
    """Auto-mock heavy ML dependencies that aren't installed on CI."""
    for mod_name in _MOCK_MODULES:
        if mod_name not in sys.modules:
            monkeypatch.setitem(sys.modules, mod_name, MagicMock())


# ---------------------------------------------------------------------------
# Sample data fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_stt_result():
    """Create a sample STTResult for testing."""
    from engines.base import STTResult

    return STTResult(
        text="For God so loved the world",
        latency_ms=150.5,
        confidence=0.92,
        avg_logprob=-0.25,
        compression_ratio=1.4,
    )


@pytest.fixture
def sample_stt_result_low_conf():
    """Create a low-confidence STTResult for testing fallback scenarios."""
    from engines.base import STTResult

    return STTResult(
        text="For God so loved the word",
        latency_ms=180.3,
        confidence=0.45,
        avg_logprob=-1.5,
        compression_ratio=2.8,
    )


@pytest.fixture
def sample_translation_result():
    """Create a sample TranslationResult for testing."""
    from engines.base import TranslationResult

    return TranslationResult(
        text="Porque de tal manera amó Dios al mundo",
        latency_ms=650.0,
        tokens_per_second=45.2,
        qe_score=0.88,
    )


@pytest.fixture(autouse=True)
def _local_operator_test_client(monkeypatch):
    """Default ASGI clients model localhost; explicit hostile peers/hosts remain testable."""
    import inspect

    from starlette.testclient import TestClient

    original = TestClient.__init__
    signature = inspect.signature(original)

    def local_client(self, *args, **kwargs):
        bound = signature.bind_partial(self, *args, **kwargs)
        bound.arguments.setdefault("base_url", "http://localhost")
        bound.arguments.setdefault("client", ("127.0.0.1", 50000))
        original(*bound.args, **bound.kwargs)

    monkeypatch.setattr(TestClient, "__init__", local_client)
    original_ws = TestClient.websocket_connect

    def local_websocket(self, url, *args, **kwargs):
        from urllib.parse import urljoin

        base = str(self.base_url).replace("https:", "wss:", 1).replace("http:", "ws:", 1)
        return original_ws(self, urljoin(base, url), *args, **kwargs)

    monkeypatch.setattr(TestClient, "websocket_connect", local_websocket)
